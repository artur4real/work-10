from ConnDB import connection
import config


def validate_password(password):
    return any(char.isdigit() for char in password) and any(char.isalpha() for char in password)


def calculate_tax(vehicle_year, estimated_value):
    TAX_RATES = {
        2000: 0.04,
        2010: 0.06,
        2020: 0.08
    }
    max_year = max(TAX_RATES.keys())
    tax_rate = next((rate for year, rate in sorted(TAX_RATES.items(), reverse=True) if vehicle_year >= year), TAX_RATES[max_year])
    tax_amount = estimated_value * tax_rate
    return tax_amount


def login():
    while True:
        username = input("Введите имя пользователя: ")
        password = input("Введите пароль: ")
        if validate_password(password):
            try:
                with connection.cursor()as cursor:
                    query = "SELECT COUNT(*) FROM users WHERE username=%s AND password=%s"
                    cursor.execute(query, (username, password))
                    result = cursor.fetchone()
                    if result[0] == 1:
                        print("Успешный вход!")
                        return username
                    else:
                        print("Неверное имя пользователя или пароль.")
            except Exception as e:
                print(f"An error occurred while executing the query: {e}")
        else:
            print("Пароль должен содержать хотя бы 1 букву и хотя бы 1 цифру")


def view_my_vehicles(username):
    try:
        with connection.cursor()as cursor:

            query = "SELECT * FROM cars WHERE owner=%s"
            cursor.execute(query, (username,))
            result = cursor.fetchall()
            if len(result) == 0:
                print("У вас нет автомобилей в собственности.")
            else:
                print("Ваши автомобили:")
                for row in result:
                    print(f"Марка: {row[1]}, Год выпуска: {row[2]}, Оценочная стоимость: {row[3]}")
    except Exception as e:
        print(f"An error occurred while executing the query: {e}")


def calculate_my_tax(username):
    try:
        with connection.cursor()as cursor:
            query = "SELECT * FROM cars WHERE owner=%s"
            cursor.execute(query, (username,))
            result = cursor.fetchall()
            total_tax_amount = 0
            if len(result) == 0:
                print("У вас нет автомобилей в собственности.")
            else:
                for row in result:
                    tax_amount = calculate_tax(row[2], row[3])
                    total_tax_amount += tax_amount
                    print(f"Автомобиль марки {row[1]} ({row[2]} года выпуска), налог к уплате: {tax_amount} руб.")
                print(f"Общая сумма налога к уплате за все автомобили: {total_tax_amount} руб.")
    except Exception as e:
        print(f"An error occurred while executing the query: {e}")


def main():
    username = login()
    while True:
        print("\nВыберите действие:")
        print("1 - Просмотреть свои автомобили")
        print("2 - Рассчитать сумму налога к уплате за свои автомобили")
        print("3 - Выйти из программы")
        choice = input()
        if choice == "1":
            view_my_vehicles(username)
        elif choice == "2":
            calculate_my_tax(username)
        elif choice == "3":
            print("До свидания!")
            break
        else:
            print("Неверный выбор. Попробуйте еще раз.")


if __name__ == "__main__":
    main()
