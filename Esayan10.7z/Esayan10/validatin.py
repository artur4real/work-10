import re

def is_valid_password(password):
    # Пароль должен содержать хотя бы 1 букву и хотя бы 1 цифру
    if re.match(r"^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{8,20}$", password):
        return True
    else:
        return False

def validate_vehicle_info(vehicle):
    # Налогоплательщик видит всю информацию об авто, проверяем наличие всех необходимых полей
    if "model" in vehicle and "year" in vehicle and "estimated_value" in vehicle:
        year = vehicle["year"]
        estimated_value = vehicle["estimated_value"]
        # Рассчитывается сумма налога к уплате в зависимости от года выпуска автомобиля
        if year < 2010:
            tax_rate = 0.04
        elif year >= 2010 and year <= 2015:
            tax_rate = 0.06
        else:
            tax_rate = 0.08
        tax_amount = estimated_value * tax_rate
        return {"tax_amount": tax_amount, "tax_rate": tax_rate}
    else:
        return False
